var eventApp = angular.module('eventApp', []);
 
eventApp.controller('EventAppCtrl', ['$scope','$http', function ($scope, $http) {
  $http.get('http://whatsdueapp.com/users.json').success(function(data) {
    $scope.events = data.events;
	console.log(data);	
  });
 
  $scope.orderProp = 'due_date';
}]);